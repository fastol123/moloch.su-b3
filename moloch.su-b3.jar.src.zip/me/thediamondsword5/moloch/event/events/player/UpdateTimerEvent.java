/*   */ package me.thediamondsword5.moloch.event.events.player;
/*   */ 
/*   */ import net.spartanb312.base.event.EventCenter;
/*   */ 
/*   */ public class UpdateTimerEvent extends EventCenter {
/*   */   public float timerSpeed;
/*   */   
/*   */   public UpdateTimerEvent(float timerSpeed) {
/* 9 */     this.timerSpeed = timerSpeed;
/*   */   }
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\event\events\player\UpdateTimerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */