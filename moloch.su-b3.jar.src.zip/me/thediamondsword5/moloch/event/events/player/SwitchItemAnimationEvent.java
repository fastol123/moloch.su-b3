/*   */ package me.thediamondsword5.moloch.event.events.player;
/*   */ 
/*   */ import net.spartanb312.base.event.EventCenter;
/*   */ 
/*   */ public class SwitchItemAnimationEvent extends EventCenter {
/*   */   public float progressFactor;
/*   */   
/*   */   public SwitchItemAnimationEvent(float progressFactor) {
/* 9 */     this.progressFactor = progressFactor;
/*   */   }
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\event\events\player\SwitchItemAnimationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */