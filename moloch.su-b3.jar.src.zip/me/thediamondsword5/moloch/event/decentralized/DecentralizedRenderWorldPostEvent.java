/*   */ package me.thediamondsword5.moloch.event.decentralized;
/*   */ 
/*   */ import me.thediamondsword5.moloch.event.events.render.RenderWorldPostEventCenter;
/*   */ import net.spartanb312.base.core.event.decentralization.DecentralizedEvent;
/*   */ 
/*   */ public class DecentralizedRenderWorldPostEvent extends DecentralizedEvent<RenderWorldPostEventCenter> {
/* 7 */   public static DecentralizedRenderWorldPostEvent instance = new DecentralizedRenderWorldPostEvent();
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\event\decentralized\DecentralizedRenderWorldPostEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */