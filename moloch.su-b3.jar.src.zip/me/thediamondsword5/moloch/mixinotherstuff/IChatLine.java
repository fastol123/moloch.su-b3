/*    */ package me.thediamondsword5.moloch.mixinotherstuff;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ChatLine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IChatLine
/*    */ {
/* 11 */   public static final HashMap<ChatLine, String> storedTime = new HashMap<>();
/*    */   
/*    */   String getTime();
/*    */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\mixinotherstuff\IChatLine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */