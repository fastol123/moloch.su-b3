package me.thediamondsword5.moloch.mixinotherstuff;

public interface IEntityRenderer {
  void invokeSetupCameraTransform(float paramFloat, int paramInt);
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\mixinotherstuff\IEntityRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */