package me.thediamondsword5.moloch.mixinotherstuff;

import java.util.List;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.Shader;

public interface AccessorInterfaceShaderGroup {
  List<Framebuffer> getListFramebuffers();
  
  List<Shader> getListShaders();
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\mixinotherstuff\AccessorInterfaceShaderGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */