/*    */ package me.thediamondsword5.moloch.core.common;
/*    */ 
/*    */ public class Visibility
/*    */ {
/*    */   private boolean visible;
/*    */   
/*    */   public Visibility(boolean visible) {
/*  8 */     this.visible = visible;
/*    */   }
/*    */   
/*    */   public void setVisible(boolean visible) {
/* 12 */     this.visible = visible;
/*    */   }
/*    */   
/*    */   public boolean getVisible() {
/* 16 */     return this.visible;
/*    */   }
/*    */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\me\thediamondsword5\moloch\core\common\Visibility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */