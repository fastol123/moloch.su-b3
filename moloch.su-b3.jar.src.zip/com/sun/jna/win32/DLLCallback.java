package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback extends Callback {
  public static final int DLL_FPTRS = 16;
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\com\sun\jna\win32\DLLCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */