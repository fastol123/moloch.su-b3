package org.spongepowered.asm.lib.tree.analysis;

public interface Value {
  int getSize();
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\org\spongepowered\asm\lib\tree\analysis\Value.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */