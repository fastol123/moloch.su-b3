package net.spartanb312.base.core.event;

public class Priority {
  public static final int LOWEST = -2147483648;
  
  public static final int LOW = 0;
  
  public static final int Medium = 1000;
  
  public static final int HIGH = 2000;
  
  public static final int HIGHEST = 2147483647;
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\core\event\Priority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */