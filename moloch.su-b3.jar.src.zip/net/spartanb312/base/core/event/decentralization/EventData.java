package net.spartanb312.base.core.event.decentralization;

public interface EventData {}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\core\event\decentralization\EventData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */