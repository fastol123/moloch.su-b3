/*   */ package net.spartanb312.base.core.setting.settings;
/*   */ 
/*   */ import net.spartanb312.base.core.setting.Setting;
/*   */ 
/*   */ public class BooleanSetting extends Setting<Boolean> {
/*   */   public BooleanSetting(String name, boolean defaultValue) {
/* 7 */     super(name, Boolean.valueOf(defaultValue));
/*   */   }
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\core\setting\settings\BooleanSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */