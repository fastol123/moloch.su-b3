package net.spartanb312.base.core.common;

public interface DisplayEnum {
  String displayName();
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\core\common\DisplayEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */