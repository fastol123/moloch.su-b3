package net.spartanb312.base.core.concurrent.task;

import net.spartanb312.base.core.concurrent.utils.Syncer;

abstract class Syncable implements Runnable {
  protected Syncer syncer;
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\core\concurrent\task\Syncable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */