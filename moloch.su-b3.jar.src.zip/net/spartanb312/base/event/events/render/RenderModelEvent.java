/*   */ package net.spartanb312.base.event.events.render;
/*   */ 
/*   */ import net.spartanb312.base.event.EventCenter;
/*   */ 
/*   */ public class RenderModelEvent extends EventCenter {
/*   */   public boolean rotating = false;
/* 7 */   public float pitch = 0.0F;
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\event\events\render\RenderModelEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */