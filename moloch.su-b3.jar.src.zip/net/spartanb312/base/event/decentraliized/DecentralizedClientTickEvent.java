/*   */ package net.spartanb312.base.event.decentraliized;
/*   */ 
/*   */ import net.spartanb312.base.core.event.decentralization.DecentralizedEvent;
/*   */ import net.spartanb312.base.core.event.decentralization.EventData;
/*   */ 
/*   */ public class DecentralizedClientTickEvent extends DecentralizedEvent<EventData> {
/* 7 */   public static DecentralizedClientTickEvent instance = new DecentralizedClientTickEvent();
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\event\decentraliized\DecentralizedClientTickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */