package net.spartanb312.base.engine;

public interface RenderTask {
  void onRender();
}


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\engine\RenderTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */