/*   */ package net.spartanb312.base.utils.math;
/*   */ 
/*   */ public class Vec3I {
/*   */   public int x;
/*   */   
/*   */   public Vec3I(int x, int y, int z) {
/* 7 */     this.x = x;
/* 8 */     this.y = y;
/* 9 */     this.z = z;
/*   */   }
/*   */   
/*   */   public int y;
/*   */   public int z;
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\bas\\utils\math\Vec3I.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */