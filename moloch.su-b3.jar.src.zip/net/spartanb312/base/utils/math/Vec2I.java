/*   */ package net.spartanb312.base.utils.math;
/*   */ 
/*   */ public class Vec2I {
/*   */   public int x;
/*   */   
/*   */   public Vec2I(int x, int y) {
/* 7 */     this.x = x;
/* 8 */     this.y = y;
/*   */   }
/*   */   
/*   */   public int y;
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\bas\\utils\math\Vec2I.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */