/*   */ package net.spartanb312.base.module;
/*   */ 
/*   */ import net.spartanb312.base.core.concurrent.task.VoidTask;
/*   */ import net.spartanb312.base.core.setting.Setting;
/*   */ 
/*   */ public class ListenerSetting extends Setting<VoidTask> {
/*   */   public ListenerSetting(String name, VoidTask defaultValue) {
/* 8 */     super(name, defaultValue);
/*   */   }
/*   */ }


/* Location:              C:\Users\XE\Desktop\moloch.su-b3.jar!\net\spartanb312\base\module\ListenerSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */